README.txt
form.html
rtf.rtf
.htaccess

Hi there! This is a lame readme file for a demo of the RTF Generation with PHP.

It should have 4 files in it. Hopefully they're self-explanatory.

It's designed to work with php3 (or better) and apache. No guarantees.

Questions? joe@artlung.com
Visit      http://www.artlung.com/
Date       04-20-2001
